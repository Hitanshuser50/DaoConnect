import { Documentation } from "@/components/documentation"

export default function DocsPage() {
  return <Documentation />
}
